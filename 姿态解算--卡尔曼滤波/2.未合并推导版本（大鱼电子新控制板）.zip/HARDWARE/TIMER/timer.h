#ifndef _TIMER_H
#define _TIMER_H

#include "stm32f10x.h"




void TIMER4_Init(u16 Per,u16 Psc);
#endif


