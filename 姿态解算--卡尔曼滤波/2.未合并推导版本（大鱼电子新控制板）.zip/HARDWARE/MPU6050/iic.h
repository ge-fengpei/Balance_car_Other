#ifndef __IIC_H
#define __IIC_H
#include "stm32f10x.h"

//ģ�� IIC �� IO ����
//#define IIC_GPIO_PORT	RCC_AHB1Periph_GPIOB
//#define IIC_GPIO		  GPIOB
//#define IIC_GPIO_SCL	GPIO_Pin_8
//#define IIC_GPIO_SDA	GPIO_Pin_9
#define IIC_GPIO_PORT	RCC_APB2Periph_GPIOB
#define IIC_GPIO		  GPIOB
#define IIC_GPIO_SCL	GPIO_Pin_6
#define IIC_GPIO_SDA	GPIO_Pin_7
//IO��������	 
#define IIC_SCLH    IIC_GPIO->ODR|= IIC_GPIO_SCL 
#define IIC_SCLL    IIC_GPIO->ODR&=~IIC_GPIO_SCL
#define IIC_SDAH    IIC_GPIO->ODR|= IIC_GPIO_SDA 
#define IIC_SDAL    IIC_GPIO->ODR&=~IIC_GPIO_SDA
#define SDA_read    (IIC_GPIO->IDR&IIC_GPIO_SDA?1:0)/* ��SDA����״̬ */

typedef enum {FALSE = 0, TRUE = !FALSE} bool;

//IIC���в�������

void IIC_Init(void);
bool Single_Write(unsigned char SlaveAddress,unsigned char REG_Address,unsigned char REG_data);	
unsigned char Single_Read(unsigned char SlaveAddress,unsigned char REG_Address);
bool I2C_Start(void);
void I2C_Stop(void);
void I2C_Ack(void);
void I2C_NoAck(void);
bool I2C_WaitAck(void);
void I2C_SendByte(u8 SendByte) ;
unsigned char I2C_RadeByte(void) ;
void I2C_NoAddr_WriteByte(unsigned char DeviceAddr,unsigned char info);
uint16_t I2C_Read_2Bytes(unsigned char DeviceAddr,unsigned char address);
uint32_t I2C_Read_3Bytes(unsigned char DeviceAddr,unsigned char address);

#endif
					
										
/*********************************************END OF FILE**********************/
