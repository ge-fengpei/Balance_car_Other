#ifndef __FILTER_H
#define __FILTER_H

#include "sys.h" 

extern float _Gyro_value_[3],_Acc_value_[3];
extern float pit_,rol_,yaw_;

#define LPF_1_(hz,t,in,out) ((out) += ( 1 / ( 1 + 1 / ( (hz) *6.28f *(t) ) ) ) *( (in) - (out) ))	
#define S_LPF_1(a,in,out) ((out) += (a) *( (in) - (out) ))	//a == 1 / ( 1 + 1 / ( (hz) *6.28f *(t) ) ) 
	




void Imput_data(void);
void calculate_RPY(void);
void IMU_UPdata(float gyro[3],float acc[3],float dT);

void LPF_1_db(float hz,float time,double in,double *out); //��ͨ�˲���2hz����0.5��������Ŀ��ֵ0.7������Լ1��������90%
int LPF_1_out(float a,double in,double *out);

double IIR_filter(double x1,int fc);
int kalman_filter(float Y_k,float X_k_);


#endif
