#include "usart2.h"




void uart2_init(u32 Baud)
{
	GPIO_InitTypeDef      GPIO_InitStruct;
	USART_InitTypeDef     USART_InitStruct;
	NVIC_InitTypeDef			NVIC_InitStruct;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2,ENABLE);
	//����PA2��ΪUSART2��Tx
	GPIO_InitStruct.GPIO_Mode=GPIO_Mode_AF_PP;//���з���\���
	GPIO_InitStruct.GPIO_Pin=GPIO_Pin_2;
	GPIO_InitStruct.GPIO_Speed=GPIO_Speed_50MHz;	
	GPIO_Init(GPIOA,&GPIO_InitStruct);
	//����PA3��ΪUSART2��Rx
	GPIO_InitStruct.GPIO_Mode=GPIO_Mode_IN_FLOATING;//���н���\����
	GPIO_InitStruct.GPIO_Pin=GPIO_Pin_3;
	GPIO_Init(GPIOA,&GPIO_InitStruct);
	//����USART2
	USART_InitStruct.USART_BaudRate=Baud;
	USART_InitStruct.USART_StopBits=USART_StopBits_1;
	USART_InitStruct.USART_WordLength=USART_WordLength_8b;
	USART_InitStruct.USART_Parity=USART_Parity_No;
	USART_InitStruct.USART_HardwareFlowControl=USART_HardwareFlowControl_None;
	USART_InitStruct.USART_Mode=USART_Mode_Rx | USART_Mode_Tx;
	USART_Init(USART2,&USART_InitStruct);
	
	NVIC_InitStruct.NVIC_IRQChannel=USART2_IRQn;
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority=3;
	NVIC_InitStruct.NVIC_IRQChannelSubPriority=3;
	NVIC_InitStruct.NVIC_IRQChannelCmd=ENABLE;
	NVIC_Init(&NVIC_InitStruct);
	//ʹ��UART5�����ж�
	USART_ITConfig(USART2,USART_IT_RXNE,ENABLE);
	
	USART_Cmd(USART2,ENABLE);	
}



///*******************************************************/
//u8 SendBuffer[256];
//u8 SendCounter = 0;
//u8 Count = 0;
////=========================================
//////�ַ����ͺ���
//void Uart_Put_Char(unsigned char DataToSend)
//{
//SendBuffer[Count++]=DataToSend;
//USART_ITConfig(USART2,USART_IT_TXE,ENABLE);
//}
////���鷢�ͺ�������Usart2_Send����һģһ����
////��ڣ�Ҫ���͵����顢Ҫ���͸������еĶ����ֽ�
//void Uart_Put_Buf(unsigned char *DataToSend,u8 data_num)
//{
//u8 i;
//for(i=0;i<data_num;i++)
//	SendBuffer[Count++]=DataToSend[i];
//if(! USART_GetITStatus(USART2,USART_IT_TXE))	
//	USART_ITConfig(USART2,USART_IT_TXE,ENABLE); //��򿪷����ж�
//}

////------------------------------------------------------------------//
//void USART2_IRQHandler(void)
//{
//if(USART_GetITStatus(USART2,USART_IT_TXE))	
//{
//	USART_SendData(USART2,SendBuffer[SendCounter++]);
//	if(SendCounter == Count)
//	{
//		USART_ITConfig(USART2,USART_IT_TXE,DISABLE);
//	}
//}
//if(USART_GetITStatus(USART2,USART_IT_RXNE))	
//{
//	u8 val = USART_ReceiveData(USART2);
//	//Uart_Put_Char(val);//����
//	Rcceive_data(val);
//}
//}
///*******************************************************/


