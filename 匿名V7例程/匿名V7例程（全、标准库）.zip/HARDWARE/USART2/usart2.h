#ifndef __USART2_H
#define __USART2_H

#include "sys.h"




void uart2_init(u32 Baud);
void Uart_Put_Char(unsigned char DataToSend);
void Uart_Put_Buf(unsigned char *DataToSend,u8 data_num);
#endif
