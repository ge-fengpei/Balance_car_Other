#ifndef  _DT_GFP_H
#define  _DT_GFP_H

#include "sys.h"


void GFP_usart_senddata(s16 a,s16 b,s16 c,s16 d,s16 e,s16 f,u8 sta);//�ߵ�
#endif
