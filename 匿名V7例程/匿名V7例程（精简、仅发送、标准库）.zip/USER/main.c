#include "stm32f10x.h"
#include "sys.h" 



int main(void)	
{
	delay_init();
	NVIC_Config();
	uart1_init(500000);	

  while(1)
	{
		GFP_usart_senddata(1,100,1000,1500,2000,2500,1);//����
		delay_ms(1);
	} 	
}

